import { db as prisma } from '../lib/db'
import * as bcrypt from 'bcryptjs'

// ─────────────────────────────────────────────────────────────────
//  KiosqueTN — Ultimate Database Seeder
//  Populates: Admin User, Product Brands, Car Brands (VehicleMakes),
//             Categories (hierarchical), Products with Variants,
//             Specs, Images, and Vehicle Compatibility
// ─────────────────────────────────────────────────────────────────

async function main() {
  console.log('🌱 Starting KiosqueTN database seeder...')

  // ── Clean all existing data in correct dependency order ───────────
  console.log('🗑️  Clearing existing data...')
  await prisma.vehicleCompatibility.deleteMany()
  await prisma.vehicleModel.deleteMany()
  await prisma.vehicleMake.deleteMany()
  await prisma.orderItem.deleteMany()
  await prisma.order.deleteMany()
  await prisma.productSpecs.deleteMany()
  await prisma.productImage.deleteMany()
  await prisma.productVariant.deleteMany()
  await prisma.product.deleteMany()
  await prisma.brand.deleteMany()
  await prisma.category.deleteMany()
  await prisma.address.deleteMany()
  await prisma.session.deleteMany()
  await prisma.account.deleteMany()
  await prisma.user.deleteMany()

  // ── Admin User ────────────────────────────────────────────────────
  console.log('👤 Creating admin user...')
  const hashedPassword = await bcrypt.hash('admin123', 10)
  await prisma.user.create({
    data: {
      name: 'Admin KiosqueTN',
      email: 'admin@kiosquetn.tn',
      passwordHash: hashedPassword,
      role: 'ADMIN',
    },
  })

  // ── Product Brands ────────────────────────────────────────────────
  console.log('🏷️  Creating lubricant brands...')
  const [
    brandTotal, brandShell, brandCastrol, brandLiquiMoly, brandMotul,
    brandYacco, brandAreca, brandAccor, brandMobil, brandElf,
    brandVeedol, brandGulf,
  ] = await Promise.all([
    prisma.brand.create({ data: { name: 'Total', slug: 'total', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/TotalEnergies_logo.svg/320px-TotalEnergies_logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Shell', slug: 'shell', logoUrl: 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e8/Shell_logo.svg/200px-Shell_logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Castrol', slug: 'castrol', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Castrol_Logo.svg/320px-Castrol_Logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Liqui Moly', slug: 'liqui-moly', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Logo_Liqui-Moly.svg/320px-Logo_Liqui-Moly.svg.png' } }),
    prisma.brand.create({ data: { name: 'Motul', slug: 'motul', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Motul_logo.svg/320px-Motul_logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Yacco', slug: 'yacco', logoUrl: 'https://www.yacco.com/wp-content/uploads/2020/06/logo-yacco.png' } }),
    prisma.brand.create({ data: { name: 'Areca', slug: 'areca', logoUrl: 'https://www.areca-lubricants.com/wp-content/uploads/2021/02/logo-areca.png' } }),
    prisma.brand.create({ data: { name: 'Accor', slug: 'accor-lubrifiants', logoUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&h=100&fit=crop' } }),
    prisma.brand.create({ data: { name: 'Mobil', slug: 'mobil', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/Mobil_logo.svg/320px-Mobil_logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Elf', slug: 'elf', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Elf_logo.svg/200px-Elf_logo.svg.png' } }),
    prisma.brand.create({ data: { name: 'Veedol', slug: 'veedol', logoUrl: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=200&h=100&fit=crop' } }),
    prisma.brand.create({ data: { name: 'Gulf', slug: 'gulf', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Gulf_Oil_logo.svg/200px-Gulf_Oil_logo.svg.png' } }),
  ])

  // ── Categories (hierarchical) ─────────────────────────────────────
  console.log('📂 Creating categories...')

  const catHuiles = await prisma.category.create({
    data: { nameFr: 'Huiles & Lubrifiants', slug: 'huiles-lubrifiants', imageUrl: 'https://images.unsplash.com/photo-1614289371518-722f2615943d?w=400&q=80' },
  })
  const catLiquides = await prisma.category.create({
    data: { nameFr: 'Liquides Techniques', slug: 'liquides-techniques', imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80' },
  })
  const catFiltres = await prisma.category.create({
    data: { nameFr: 'Filtres', slug: 'filtres', imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400&q=80' },
  })
  const catAdditifs = await prisma.category.create({
    data: { nameFr: 'Additifs & Traitements', slug: 'additifs-traitements', imageUrl: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400&q=80' },
  })
  const catEntretien = await prisma.category.create({
    data: { nameFr: 'Entretien & Nettoyage', slug: 'entretien-nettoyage', imageUrl: 'https://images.unsplash.com/photo-1625047509248-ec889cbff17f?w=400&q=80' },
  })

  // Sub-categories — Huiles
  const [catHMoteur, catHBoite, catHPont, catHMoto, catHIndustrielle] = await Promise.all([
    prisma.category.create({ data: { nameFr: 'Huile Moteur', slug: 'huile-moteur', parentId: catHuiles.id, imageUrl: 'https://images.unsplash.com/photo-1621245131495-21d3f9479b15?w=400&q=80' } }),
    prisma.category.create({ data: { nameFr: 'Huile Boîte de Vitesses', slug: 'huile-boite-vitesses', parentId: catHuiles.id, imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80' } }),
    prisma.category.create({ data: { nameFr: 'Huile de Pont', slug: 'huile-pont', parentId: catHuiles.id, imageUrl: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400&q=80' } }),
    prisma.category.create({ data: { nameFr: 'Huile Moto', slug: 'huile-moto', parentId: catHuiles.id, imageUrl: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&q=80' } }),
    prisma.category.create({ data: { nameFr: 'Huile Industrielle', slug: 'huile-industrielle', parentId: catHuiles.id, imageUrl: 'https://images.unsplash.com/photo-1565008576549-57569a49371d?w=400&q=80' } }),
  ])

  // Sub-categories — Liquides
  const [catLFrein, catLRefroid, catLLaveGlace, catLDirection] = await Promise.all([
    prisma.category.create({ data: { nameFr: 'Liquide de Frein', slug: 'liquide-frein', parentId: catLiquides.id } }),
    prisma.category.create({ data: { nameFr: 'Liquide de Refroidissement', slug: 'liquide-refroidissement', parentId: catLiquides.id } }),
    prisma.category.create({ data: { nameFr: 'Lave-Glace', slug: 'lave-glace', parentId: catLiquides.id } }),
    prisma.category.create({ data: { nameFr: 'Liquide Direction Assistée', slug: 'liquide-direction-assistee', parentId: catLiquides.id } }),
  ])

  // Sub-categories — Filtres
  const [catFHuile, catFAir, catFCarburant, catFHabitacle] = await Promise.all([
    prisma.category.create({ data: { nameFr: 'Filtre à Huile', slug: 'filtre-huile', parentId: catFiltres.id } }),
    prisma.category.create({ data: { nameFr: "Filtre à Air", slug: 'filtre-air', parentId: catFiltres.id } }),
    prisma.category.create({ data: { nameFr: 'Filtre Carburant', slug: 'filtre-carburant', parentId: catFiltres.id } }),
    prisma.category.create({ data: { nameFr: "Filtre d'Habitacle", slug: 'filtre-habitacle', parentId: catFiltres.id } }),
  ])

  // Sub-categories — Additifs
  const [catACarburant, catAMoteur, catATrans] = await Promise.all([
    prisma.category.create({ data: { nameFr: 'Additif Carburant', slug: 'additif-carburant', parentId: catAdditifs.id } }),
    prisma.category.create({ data: { nameFr: 'Additif Moteur', slug: 'additif-moteur', parentId: catAdditifs.id } }),
    prisma.category.create({ data: { nameFr: 'Additif Transmission', slug: 'additif-transmission', parentId: catAdditifs.id } }),
  ])

  // ── Vehicle Makes ─────────────────────────────────────────────────
  console.log('🚗 Creating vehicle makes and models...')
  const [
    makeRenault, makePeugeot, makeVW, makeAudi, makeMercedes,
    makeBMW, makeKia, makeHyundai, makeToyota, makeCitroen,
    makeNissan, makeOpel, makeDacia, makeFord, makeFiat,
    makeMitsubishi, makeIsuzu, makeSuzuki
  ] = await Promise.all([
    prisma.vehicleMake.create({ data: { name: 'Renault', slug: 'renault' } }),
    prisma.vehicleMake.create({ data: { name: 'Peugeot', slug: 'peugeot' } }),
    prisma.vehicleMake.create({ data: { name: 'Volkswagen', slug: 'volkswagen' } }),
    prisma.vehicleMake.create({ data: { name: 'Audi', slug: 'audi' } }),
    prisma.vehicleMake.create({ data: { name: 'Mercedes-Benz', slug: 'mercedes-benz' } }),
    prisma.vehicleMake.create({ data: { name: 'BMW', slug: 'bmw' } }),
    prisma.vehicleMake.create({ data: { name: 'Kia', slug: 'kia' } }),
    prisma.vehicleMake.create({ data: { name: 'Hyundai', slug: 'hyundai' } }),
    prisma.vehicleMake.create({ data: { name: 'Toyota', slug: 'toyota' } }),
    prisma.vehicleMake.create({ data: { name: 'Citroën', slug: 'citroen' } }),
    prisma.vehicleMake.create({ data: { name: 'Nissan', slug: 'nissan' } }),
    prisma.vehicleMake.create({ data: { name: 'Opel', slug: 'opel' } }),
    prisma.vehicleMake.create({ data: { name: 'Dacia', slug: 'dacia' } }),
    prisma.vehicleMake.create({ data: { name: 'Ford', slug: 'ford' } }),
    prisma.vehicleMake.create({ data: { name: 'Fiat', slug: 'fiat' } }),
    prisma.vehicleMake.create({ data: { name: 'Mitsubishi', slug: 'mitsubishi' } }),
    prisma.vehicleMake.create({ data: { name: 'Isuzu', slug: 'isuzu' } }),
    prisma.vehicleMake.create({ data: { name: 'Suzuki', slug: 'suzuki' } }),
  ])

  // Vehicle Models
  const [
    modelClio, modelMegane, modelDuster,
    model308, model207, modelPartner,
    modelGolf, modelPassat, modelPolo,
    modelA4, modelA3,
    modelC220, modelE220,
    model3Series, model5Series,
    modelSportage, modelRio,
    modelTucson, modelElantra,
    modelCorolla, modelCamry, modelHilux,
    modelC3, modelBerlingo,
    modelQashqai,
    modelAstra,
    modelLogan, modelSandero,
    modelFocus,
    modelPunto,
    modelL200,
    modelDMax,
    modelSwift,
  ] = await Promise.all([
    // Renault
    prisma.vehicleModel.create({ data: { makeId: makeRenault.id, name: 'Clio IV', slug: 'renault-clio-iv' } }),
    prisma.vehicleModel.create({ data: { makeId: makeRenault.id, name: 'Mégane III', slug: 'renault-megane-iii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeRenault.id, name: 'Duster', slug: 'renault-duster' } }),
    // Peugeot
    prisma.vehicleModel.create({ data: { makeId: makePeugeot.id, name: '308 II', slug: 'peugeot-308-ii' } }),
    prisma.vehicleModel.create({ data: { makeId: makePeugeot.id, name: '207', slug: 'peugeot-207' } }),
    prisma.vehicleModel.create({ data: { makeId: makePeugeot.id, name: 'Partner', slug: 'peugeot-partner' } }),
    // VW
    prisma.vehicleModel.create({ data: { makeId: makeVW.id, name: 'Golf VII', slug: 'vw-golf-vii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeVW.id, name: 'Passat B8', slug: 'vw-passat-b8' } }),
    prisma.vehicleModel.create({ data: { makeId: makeVW.id, name: 'Polo VI', slug: 'vw-polo-vi' } }),
    // Audi
    prisma.vehicleModel.create({ data: { makeId: makeAudi.id, name: 'A4 (B9)', slug: 'audi-a4-b9' } }),
    prisma.vehicleModel.create({ data: { makeId: makeAudi.id, name: 'A3 (8V)', slug: 'audi-a3-8v' } }),
    // Mercedes
    prisma.vehicleModel.create({ data: { makeId: makeMercedes.id, name: 'C 220 d', slug: 'mercedes-c220d' } }),
    prisma.vehicleModel.create({ data: { makeId: makeMercedes.id, name: 'E 220 d', slug: 'mercedes-e220d' } }),
    // BMW
    prisma.vehicleModel.create({ data: { makeId: makeBMW.id, name: 'Série 3 (F30)', slug: 'bmw-serie3-f30' } }),
    prisma.vehicleModel.create({ data: { makeId: makeBMW.id, name: 'Série 5 (F10)', slug: 'bmw-serie5-f10' } }),
    // Kia
    prisma.vehicleModel.create({ data: { makeId: makeKia.id, name: 'Sportage IV', slug: 'kia-sportage-iv' } }),
    prisma.vehicleModel.create({ data: { makeId: makeKia.id, name: 'Rio IV', slug: 'kia-rio-iv' } }),
    // Hyundai
    prisma.vehicleModel.create({ data: { makeId: makeHyundai.id, name: 'Tucson III', slug: 'hyundai-tucson-iii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeHyundai.id, name: 'Elantra VI', slug: 'hyundai-elantra-vi' } }),
    // Toyota
    prisma.vehicleModel.create({ data: { makeId: makeToyota.id, name: 'Corolla E210', slug: 'toyota-corolla-e210' } }),
    prisma.vehicleModel.create({ data: { makeId: makeToyota.id, name: 'Camry VIII', slug: 'toyota-camry-viii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeToyota.id, name: 'Hilux VIII', slug: 'toyota-hilux-viii' } }),
    // Citroën
    prisma.vehicleModel.create({ data: { makeId: makeCitroen.id, name: 'C3 III', slug: 'citroen-c3-iii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeCitroen.id, name: 'Berlingo III', slug: 'citroen-berlingo-iii' } }),
    // Nissan
    prisma.vehicleModel.create({ data: { makeId: makeNissan.id, name: 'Qashqai II', slug: 'nissan-qashqai-ii' } }),
    // Opel
    prisma.vehicleModel.create({ data: { makeId: makeOpel.id, name: 'Astra K', slug: 'opel-astra-k' } }),
    // Dacia
    prisma.vehicleModel.create({ data: { makeId: makeDacia.id, name: 'Logan II', slug: 'dacia-logan-ii' } }),
    prisma.vehicleModel.create({ data: { makeId: makeDacia.id, name: 'Sandero II', slug: 'dacia-sandero-ii' } }),
    // Ford
    prisma.vehicleModel.create({ data: { makeId: makeFord.id, name: 'Focus III', slug: 'ford-focus-iii' } }),
    // Fiat
    prisma.vehicleModel.create({ data: { makeId: makeFiat.id, name: 'Punto III', slug: 'fiat-punto-iii' } }),
    // Mitsubishi
    prisma.vehicleModel.create({ data: { makeId: makeMitsubishi.id, name: 'L200 V', slug: 'mitsubishi-l200-v' } }),
    // Isuzu
    prisma.vehicleModel.create({ data: { makeId: makeIsuzu.id, name: 'D-Max III', slug: 'isuzu-dmax-iii' } }),
    // Suzuki
    prisma.vehicleModel.create({ data: { makeId: makeSuzuki.id, name: 'Swift V', slug: 'suzuki-swift-v' } }),
  ])

  // ── Products ──────────────────────────────────────────────────────
  console.log('📦 Creating products...')

  // Helper to build product data
  const mkProduct = async (data: {
    sku: string; name: string; slug: string; desc: string;
    brandId: string; categoryId: string; isFeatured?: boolean;
    images: { url: string; altFr: string }[];
    variants: { skuVariant: string; volume: string; price: number; stock: number }[];
    specs?: { viscosity?: string; apiStandard?: string; aeceaStandard?: string; isFullySynth?: boolean; isSemiSynth?: boolean; isMinerale?: boolean };
    compatible?: { modelId: string; engine?: string; yearFrom?: number; yearTo?: number }[];
  }) => {
    return prisma.product.create({
      data: {
        sku: data.sku,
        nameFr: data.name,
        slug: data.slug,
        description: data.desc,
        brandId: data.brandId,
        categoryId: data.categoryId,
        isPublished: true,
        isFeatured: data.isFeatured ?? false,
        images: {
          create: data.images.map((img, i) => ({ url: img.url, altFr: img.altFr, isPrimary: i === 0, sortOrder: i })),
        },
        variants: {
          create: data.variants.map(v => ({ skuVariant: v.skuVariant, volume: v.volume, price: v.price, stockQty: v.stock })),
        },
        specs: data.specs ? { create: data.specs } : undefined,
        compatibilities: data.compatible ? {
          create: data.compatible.map(c => ({
            vehicleModelId: c.modelId,
            engineCode: c.engine,
            yearFrom: c.yearFrom,
            yearTo: c.yearTo,
          })),
        } : undefined,
      },
    })
  }

  // ── Huiles Moteur (flagship products) ────────────────────────────
  await mkProduct({
    sku: 'TOT-QI-5W30-5L', name: 'Total Quartz Ineo First 0W-30', slug: 'total-quartz-ineo-first-0w30',
    desc: "L'huile Total Quartz Ineo First 0W-30 est une huile synthétique spécialement formulée pour les véhicules PSA (Peugeot-Citroën). Elle garantit une protection maximale du moteur dès le démarrage à froid, réduit la consommation de carburant et prolonge les intervalles de vidange. Compatible avec les filtres à particules (FAP).",
    brandId: brandTotal.id, categoryId: catHMoteur.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1614289371518-722f2615943d?w=800&q=80', altFr: 'Total Quartz Ineo First 0W-30' },
      { url: 'https://images.unsplash.com/photo-1621245131495-21d3f9479b15?w=800&q=80', altFr: 'Total Quartz 0W-30 détail' },
    ],
    variants: [
      { skuVariant: 'TOT-0W30-1L', volume: '1L', price: 39.90, stock: 120 },
      { skuVariant: 'TOT-0W30-5L', volume: '5L', price: 178.50, stock: 85 },
    ],
    specs: { viscosity: '0W-30', apiStandard: 'API SN', aeceaStandard: 'ACEA C1', isFullySynth: true },
    compatible: [
      { modelId: model308.id, engine: '1.6 BlueHDi 120', yearFrom: 2014, yearTo: 2021 },
      { modelId: model207.id, engine: '1.6 HDi 90', yearFrom: 2006, yearTo: 2012 },
      { modelId: modelPartner.id, engine: '1.6 BlueHDi 100', yearFrom: 2015, yearTo: 2023 },
      { modelId: modelC3.id, engine: '1.2 PureTech 110', yearFrom: 2016, yearTo: 2023 },
      { modelId: modelBerlingo.id, engine: '1.5 BlueHDi 100', yearFrom: 2018, yearTo: 2023 },
    ],
  })

  await mkProduct({
    sku: 'SHE-HX8-5W40', name: 'Shell Helix Ultra 5W-40', slug: 'shell-helix-ultra-5w40',
    desc: "Shell Helix Ultra 5W-40 est une huile moteur entièrement synthétique offrant une protection ultime à base de technologie PurePlus®. Conçue pour résister aux conditions de conduite les plus extrêmes, elle maintient la propreté du moteur et assure une performance maximale même après de longs intervalles de vidange.",
    brandId: brandShell.id, categoryId: catHMoteur.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80', altFr: 'Shell Helix Ultra 5W-40' },
    ],
    variants: [
      { skuVariant: 'SHE-HU-5W40-1L', volume: '1L', price: 45.00, stock: 95 },
      { skuVariant: 'SHE-HU-5W40-4L', volume: '4L', price: 168.00, stock: 60 },
      { skuVariant: 'SHE-HU-5W40-5L', volume: '5L', price: 205.00, stock: 45 },
    ],
    specs: { viscosity: '5W-40', apiStandard: 'API SN Plus', aeceaStandard: 'ACEA A3/B4', isFullySynth: true },
    compatible: [
      { modelId: modelGolf.id, engine: '2.0 TDI 150', yearFrom: 2013, yearTo: 2020 },
      { modelId: modelPassat.id, engine: '2.0 TDI 190', yearFrom: 2015, yearTo: 2023 },
      { modelId: modelA4.id, engine: '2.0 TDI 150', yearFrom: 2015, yearTo: 2022 },
      { modelId: modelA3.id, engine: '1.6 TDI 110', yearFrom: 2012, yearTo: 2020 },
      { modelId: model3Series.id, engine: '318d', yearFrom: 2012, yearTo: 2019 },
      { modelId: model5Series.id, engine: '520d', yearFrom: 2010, yearTo: 2016 },
    ],
  })

  await mkProduct({
    sku: 'CAS-EDGE-5W40', name: 'Castrol EDGE 5W-40', slug: 'castrol-edge-5w40',
    desc: "Castrol EDGE avec technologie Fluid TITANIUM™ est la solution premium pour les moteurs modernes à haute performance. Formulée avec du Bisphénol de Titane pour renforcer le film lubrifiant sous pression maximale, elle réduit de 15% la friction entre les pièces mobiles et prolonge la durée de vie du moteur.",
    brandId: brandCastrol.id, categoryId: catHMoteur.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1580983561371-7f4b242d8ec0?w=800&q=80', altFr: 'Castrol EDGE 5W-40' },
    ],
    variants: [
      { skuVariant: 'CAS-EDGE-5W40-1L', volume: '1L', price: 48.00, stock: 80 },
      { skuVariant: 'CAS-EDGE-5W40-4L', volume: '4L', price: 178.00, stock: 55 },
      { skuVariant: 'CAS-EDGE-5W40-5L', volume: '5L', price: 215.00, stock: 40 },
    ],
    specs: { viscosity: '5W-40', apiStandard: 'API SN', aeceaStandard: 'ACEA C3', isFullySynth: true },
    compatible: [
      { modelId: modelC220.id, engine: 'OM651', yearFrom: 2014, yearTo: 2018 },
      { modelId: modelE220.id, engine: 'OM654', yearFrom: 2016, yearTo: 2023 },
      { modelId: model3Series.id, engine: '320d', yearFrom: 2012, yearTo: 2019 },
    ],
  })

  await mkProduct({
    sku: 'LM-LM-5W40', name: 'Liqui Moly Molygen New Generation 5W-40', slug: 'liqui-moly-molygen-5w40',
    desc: "Huile de synthèse haut de gamme de la marque allemande Liqui Moly, enrichie de molybdène (Mo) — un additif anti-usure exceptionnel qui crée une couche de protection supérieure sur les surfaces métalliques. Idéale pour les motorisations de grande cylindrée ou soumises à un régime sportif.",
    brandId: brandLiquiMoly.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1542362567-b07e54358753?w=800&q=80', altFr: 'Liqui Moly Molygen 5W-40' },
    ],
    variants: [
      { skuVariant: 'LM-MOL-5W40-1L', volume: '1L', price: 52.00, stock: 70 },
      { skuVariant: 'LM-MOL-5W40-4L', volume: '4L', price: 195.00, stock: 50 },
      { skuVariant: 'LM-MOL-5W40-5L', volume: '5L', price: 235.00, stock: 30 },
    ],
    specs: { viscosity: '5W-40', apiStandard: 'API SN', aeceaStandard: 'ACEA A3/B4', isFullySynth: true },
    compatible: [
      { modelId: modelGolf.id, engine: '1.4 TSI 125', yearFrom: 2013, yearTo: 2020 },
      { modelId: modelPolo.id, engine: '1.0 TSI 95', yearFrom: 2017, yearTo: 2023 },
      { modelId: modelSportage.id, engine: '2.0 CRDi 185', yearFrom: 2015, yearTo: 2022 },
    ],
  })

  await mkProduct({
    sku: 'MOT-8100-5W30', name: 'Motul 8100 X-Cess 5W-30', slug: 'motul-8100-xcess-5w30',
    desc: "Motul 8100 X-Cess 5W-30 est une huile 100% synthétique formulée à partir de bases ester et PAO. Parfaitement adaptée aux moteurs turbo essence et diesel modernes, elle offre une excellente stabilité thermique et une résistance aux dépôts dans les conditions de conduite sportive ou intensive.",
    brandId: brandMotul.id, categoryId: catHMoteur.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80', altFr: 'Motul 8100 5W-30' },
    ],
    variants: [
      { skuVariant: 'MOT-8100-5W30-1L', volume: '1L', price: 55.00, stock: 90 },
      { skuVariant: 'MOT-8100-5W30-5L', volume: '5L', price: 248.00, stock: 35 },
    ],
    specs: { viscosity: '5W-30', apiStandard: 'API SN', aeceaStandard: 'ACEA A3/B4', isFullySynth: true },
    compatible: [
      { modelId: modelMegane.id, engine: '1.5 dCi 110', yearFrom: 2012, yearTo: 2019 },
      { modelId: modelClio.id, engine: '1.5 dCi 90', yearFrom: 2012, yearTo: 2019 },
      { modelId: modelDuster.id, engine: '1.5 dCi 110', yearFrom: 2010, yearTo: 2017 },
    ],
  })

  await mkProduct({
    sku: 'YAC-VX-5W40', name: 'Yacco VX 1000 LL 5W-40', slug: 'yacco-vx-1000-ll-5w40',
    desc: "Yacco VX 1000 LL est une huile 100% synthétique longue durée développée en France, adaptée aux moteurs essence et diesel. Sa formule avancée assure des intervalles de vidange allongés jusqu'à 30 000 km et une protection optimale contre l'usure et l'oxydation à hautes températures.",
    brandId: brandYacco.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1625047509248-ec889cbff17f?w=800&q=80', altFr: 'Yacco VX 1000 LL 5W-40' },
    ],
    variants: [
      { skuVariant: 'YAC-VX1000-1L', volume: '1L', price: 41.00, stock: 100 },
      { skuVariant: 'YAC-VX1000-5L', volume: '5L', price: 185.00, stock: 65 },
      { skuVariant: 'YAC-VX1000-20L', volume: '20L', price: 650.00, stock: 15 },
    ],
    specs: { viscosity: '5W-40', apiStandard: 'API SN', aeceaStandard: 'ACEA A3/B4', isFullySynth: true },
    compatible: [
      { modelId: modelTucson.id, engine: '1.6 CRDi 116', yearFrom: 2015, yearTo: 2021 },
      { modelId: modelElantra.id, engine: '1.4 T-GDI 140', yearFrom: 2016, yearTo: 2022 },
    ],
  })

  await mkProduct({
    sku: 'TOT-RIM-15W40', name: 'Total Rubia TIR 7400 15W-40', slug: 'total-rubia-tir-7400-15w40',
    desc: "Total Rubia TIR 7400 est une huile minérale améliorée pour moteurs diesel de véhicules utilitaires et camions. Particulièrement recommandée pour les flottes de transport longue distance opérant en Tunisie et en Afrique du Nord. Protège efficacement contre l'usure, les dépôts et la corrosion même dans des conditions climatiques extrêmes.",
    brandId: brandTotal.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1565008576549-57569a49371d?w=800&q=80', altFr: 'Total Rubia TIR 7400 15W-40' },
    ],
    variants: [
      { skuVariant: 'TOT-RUB-15W40-5L', volume: '5L', price: 89.00, stock: 150 },
      { skuVariant: 'TOT-RUB-15W40-20L', volume: '20L', price: 315.00, stock: 40 },
      { skuVariant: 'TOT-RUB-15W40-60L', volume: '60L', price: 890.00, stock: 10 },
      { skuVariant: 'TOT-RUB-15W40-208L', volume: '208L', price: 2950.00, stock: 5 },
    ],
    specs: { viscosity: '15W-40', apiStandard: 'API CI-4', aeceaStandard: 'ACEA E7', isMinerale: true },
    compatible: [
      { modelId: modelHilux.id, engine: '2.8 D-4D 204', yearFrom: 2015, yearTo: 2023 },
      { modelId: modelL200.id, engine: '2.2 DI-D 150', yearFrom: 2015, yearTo: 2023 },
      { modelId: modelDMax.id, engine: '1.9 DDTi 163', yearFrom: 2019, yearTo: 2023 },
    ],
  })

  await mkProduct({
    sku: 'SHE-RIM-15W40', name: 'Shell Rimula R3 Turbo 15W-40', slug: 'shell-rimula-r3-turbo-15w40',
    desc: "Shell Rimula R3 Turbo 15W-40 est la solution de référence pour les moteurs diesel poids lourds. Avec sa formulation Triple Protection Plus™, elle lutte simultanément contre l'usure, le dépôt et l'acidité. Très répandue dans les garages tunisiens pour les camions, tracteurs et véhicules utilitaires.",
    brandId: brandShell.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=800&q=80', altFr: 'Shell Rimula R3 Turbo 15W-40' },
    ],
    variants: [
      { skuVariant: 'SHE-RIM-15W40-5L', volume: '5L', price: 82.00, stock: 200 },
      { skuVariant: 'SHE-RIM-15W40-20L', volume: '20L', price: 295.00, stock: 55 },
      { skuVariant: 'SHE-RIM-15W40-208L', volume: '208L', price: 2800.00, stock: 8 },
    ],
    specs: { viscosity: '15W-40', apiStandard: 'API CI-4 Plus', aeceaStandard: 'ACEA E7/E5', isMinerale: true },
  })

  await mkProduct({
    sku: 'ELF-EVO-10W40', name: 'Elf Evolution 900 SXR 10W-40', slug: 'elf-evolution-900-sxr-10w40',
    desc: "Elf Evolution 900 SXR est une huile semi-synthétique polyvalente adaptée aux moteurs essence et diesel. Sa technologie SXR (Synthesis Extended Range) assure une protection rapide au démarrage et une grande stabilité thermique. Idéale pour les conditions de circulation tunisiennes entre ville et autoroute.",
    brandId: brandElf.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&q=80', altFr: 'Elf Evolution 900 SXR 10W-40' },
    ],
    variants: [
      { skuVariant: 'ELF-EVO-10W40-1L', volume: '1L', price: 29.00, stock: 180 },
      { skuVariant: 'ELF-EVO-10W40-4L', volume: '4L', price: 108.00, stock: 100 },
      { skuVariant: 'ELF-EVO-10W40-5L', volume: '5L', price: 132.00, stock: 75 },
    ],
    specs: { viscosity: '10W-40', apiStandard: 'API SN', aeceaStandard: 'ACEA A3/B4', isSemiSynth: true },
    compatible: [
      { modelId: modelClio.id, engine: '1.5 dCi 75', yearFrom: 2009, yearTo: 2019 },
      { modelId: modelMegane.id, engine: '1.6 16V 115', yearFrom: 2008, yearTo: 2016 },
      { modelId: modelLogan.id, engine: '1.5 dCi 90', yearFrom: 2012, yearTo: 2020 },
      { modelId: modelSandero.id, engine: '1.0 SCe 75', yearFrom: 2012, yearTo: 2021 },
    ],
  })

  await mkProduct({
    sku: 'MOB-1-0W40', name: 'Mobil 1 Extended Life 0W-40', slug: 'mobil-1-extended-life-0w40',
    desc: "Mobil 1 Extended Life 0W-40 est une huile 100% synthétique de la gamme phare de ExxonMobil. Conçue pour des vidanges pouvant aller jusqu'à 25 000 km, elle offre une protection exceptionnelle à froid (-50°C) comme à chaud (+160°C). Recommandée pour les berlines allemandes haut de gamme.",
    brandId: brandMobil.id, categoryId: catHMoteur.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1580983561371-7f4b242d8ec0?w=800&q=80', altFr: 'Mobil 1 Extended Life 0W-40' },
    ],
    variants: [
      { skuVariant: 'MOB1-0W40-1L', volume: '1L', price: 58.00, stock: 60 },
      { skuVariant: 'MOB1-0W40-4L', volume: '4L', price: 215.00, stock: 40 },
    ],
    specs: { viscosity: '0W-40', apiStandard: 'API SN Plus', aeceaStandard: 'ACEA A3/B4', isFullySynth: true },
    compatible: [
      { modelId: modelC220.id, engine: 'OM651 2.2 CDI', yearFrom: 2011, yearTo: 2018 },
      { modelId: modelE220.id, engine: 'OM654 2.0 CDI', yearFrom: 2016, yearTo: 2023 },
      { modelId: model3Series.id, engine: '330d 260ch', yearFrom: 2015, yearTo: 2019 },
      { modelId: model5Series.id, engine: '530d 286ch', yearFrom: 2013, yearTo: 2016 },
    ],
  })

  // ── Huile Boîte / Pont ────────────────────────────────────────────
  await mkProduct({
    sku: 'TOT-BVA-ATF', name: 'Total Fluide ATF VI', slug: 'total-fluide-atf-vi',
    desc: "Total Fluide ATF VI est le liquide de référence pour boîtes de vitesses automatiques modernes. Compatible avec la plupart des spécifications constructeurs (Dexron VI, Toyota WS, Honda DW-1...). Il assure une fluidité parfaite des changements de rapports, réduit les à-coups et prolonge la durée de vie de la transmission.",
    brandId: brandTotal.id, categoryId: catHBoite.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&q=80', altFr: 'Total Fluide ATF VI' },
    ],
    variants: [
      { skuVariant: 'TOT-ATF6-1L', volume: '1L', price: 34.00, stock: 90 },
      { skuVariant: 'TOT-ATF6-5L', volume: '5L', price: 155.00, stock: 45 },
    ],
    specs: { apiStandard: 'Dexron VI', aeceaStandard: 'Toyota WS' },
    compatible: [
      { modelId: modelCorolla.id, engine: '1.8 VVT-i 140', yearFrom: 2019, yearTo: 2023 },
      { modelId: modelCamry.id, engine: '2.5 VVT-i 218', yearFrom: 2019, yearTo: 2023 },
      { modelId: modelTucson.id, engine: '2.0 T-GDI 185', yearFrom: 2015, yearTo: 2022 },
    ],
  })

  await mkProduct({
    sku: 'LM-GEAR-75W90', name: 'Liqui Moly Hypoid-Getriebeöl 75W-90', slug: 'liqui-moly-hypoid-75w90',
    desc: "Huile de transmission synthétique pour boîtes manuelles et ponts. La viscosité 75W-90 permet d'améliorer le rendement de la transmission tout en réduisant la consommation de carburant. Convient aux boîtes 5 et 6 rapports des véhicules modernes.",
    brandId: brandLiquiMoly.id, categoryId: catHBoite.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1542362567-b07e54358753?w=800&q=80', altFr: 'Liqui Moly Hypoid 75W-90' },
    ],
    variants: [
      { skuVariant: 'LM-GBX-75W90-1L', volume: '1L', price: 42.00, stock: 70 },
      { skuVariant: 'LM-GBX-75W90-5L', volume: '5L', price: 195.00, stock: 30 },
    ],
    specs: { viscosity: '75W-90', apiStandard: 'API GL-5', isFullySynth: true },
    compatible: [
      { modelId: modelGolf.id, engine: 'Boîte 6 rapports DSG', yearFrom: 2013, yearTo: 2020 },
      { modelId: modelPassat.id, engine: 'Boîte 7 rapports DSG', yearFrom: 2015, yearTo: 2023 },
    ],
  })

  // ── Huile Moto ────────────────────────────────────────────────────
  await mkProduct({
    sku: 'MOT-MVX-10W50', name: 'Motul 7100 4T 10W-50', slug: 'motul-7100-4t-10w50',
    desc: "Motul 7100 4T est l'huile de référence pour moteurs moto 4 temps de haute performance. Sa formulation 100% ester offre une protection exceptionnelle des carters humides (embrayage et boîte inclus), des réductions d'usure documentées sur piste et une excellente résistance à la dégradation thermique.",
    brandId: brandMotul.id, categoryId: catHMoto.id, isFeatured: true,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&q=80', altFr: 'Motul 7100 4T 10W-50' },
    ],
    variants: [
      { skuVariant: 'MOT-7100-10W50-1L', volume: '1L', price: 62.00, stock: 80 },
      { skuVariant: 'MOT-7100-10W50-4L', volume: '4L', price: 235.00, stock: 25 },
    ],
    specs: { viscosity: '10W-50', apiStandard: 'API SN', isFullySynth: true },
  })

  await mkProduct({
    sku: 'CAS-ACT-10W40', name: 'Castrol Power 1 4T 10W-40', slug: 'castrol-power1-4t-10w40',
    desc: "Castrol Power 1 4T est une huile semi-synthétique pour motos 4 temps. Sa technologie Trizone Protection™ protège simultanément le moteur, l'embrayage et la boîte de vitesses. Parfaite pour une utilisation quotidienne en ville ou sur route.",
    brandId: brandCastrol.id, categoryId: catHMoto.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80', altFr: 'Castrol Power 1 4T 10W-40' },
    ],
    variants: [
      { skuVariant: 'CAS-PWR-10W40-1L', volume: '1L', price: 34.00, stock: 120 },
      { skuVariant: 'CAS-PWR-10W40-4L', volume: '4L', price: 128.00, stock: 40 },
    ],
    specs: { viscosity: '10W-40', apiStandard: 'API SL', aeceaStandard: 'JASO MA2', isSemiSynth: true },
  })

  // ── Liquides Techniques ───────────────────────────────────────────
  await mkProduct({
    sku: 'TOT-DOT4', name: 'Total Dot 4 Liquide de Frein', slug: 'total-dot4-liquide-frein',
    desc: "Liquide de frein synthétique Total Dot 4 pour systèmes hydrauliques de freinage et d'embrayage. Point d'ébullition sec (>230°C) et mouillé (>155°C) conformes aux normes FMVSS 116 DOT 4 et ISO 4925. Changement recommandé tous les 2 ans pour garantir la sécurité du freinage.",
    brandId: brandTotal.id, categoryId: catLFrein.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80', altFr: 'Total DOT4 Liquide de frein' },
    ],
    variants: [
      { skuVariant: 'TOT-DOT4-0.25L', volume: '0.25L', price: 8.50, stock: 300 },
      { skuVariant: 'TOT-DOT4-0.5L', volume: '0.5L', price: 14.00, stock: 250 },
      { skuVariant: 'TOT-DOT4-1L', volume: '1L', price: 24.00, stock: 120 },
    ],
    specs: { apiStandard: 'DOT 4' },
  })

  await mkProduct({
    sku: 'SHE-COOLANT-G', name: 'Shell Glycoshell Longlife Coolant', slug: 'shell-glycoshell-longlife',
    desc: "Liquide de refroidissement Shell Glycoshell Longlife à base de glycol OAT (Organic Acid Technology). Protection anti-gel jusqu'à -37°C, anti-corrosion et anti-calcaire pour tous types de moteurs. Durée de vie jusqu'à 5 ans ou 250 000 km.",
    brandId: brandShell.id, categoryId: catLRefroid.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1614289371518-722f2615943d?w=800&q=80', altFr: 'Shell Glycoshell Coolant' },
    ],
    variants: [
      { skuVariant: 'SHE-COOL-1L', volume: '1L', price: 18.00, stock: 200 },
      { skuVariant: 'SHE-COOL-5L', volume: '5L', price: 78.00, stock: 80 },
    ],
    specs: { apiStandard: 'OAT G12+' },
  })

  await mkProduct({
    sku: 'TOT-CLEAR-LG', name: 'Total Clear Lave-Glace Été', slug: 'total-clear-lave-glace-ete',
    desc: "Liquide lave-glace concentré Total Clear pour une visibilité optimale toute l'année. Formule anti-calcaire, anti-bactérienne et désodorisante. Dégraisse efficacement les insectes, poussières et traces de goudron. Préparé pour une utilisation à 100% ou dilué selon la saison.",
    brandId: brandTotal.id, categoryId: catLLaveGlace.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1625047509248-ec889cbff17f?w=800&q=80', altFr: 'Total Clear Lave-Glace' },
    ],
    variants: [
      { skuVariant: 'TOT-LG-1L', volume: '1L', price: 6.50, stock: 500 },
      { skuVariant: 'TOT-LG-5L', volume: '5L', price: 25.00, stock: 200 },
    ],
  })

  // ── Additifs ──────────────────────────────────────────────────────
  await mkProduct({
    sku: 'LM-DIESEL-ADD', name: 'Liqui Moly Diesel Spülung 500ml', slug: 'liqui-moly-diesel-spurlung-500ml',
    desc: "Additif nettoyant injecteur diesel Liqui Moly. Élimine les dépôts carbonés des injecteurs et de la chambre de combustion. Réduit la consommation de carburant, améliore la puissance du moteur et réduit les émissions de particules. Convient à tous les moteurs diesel, y compris ceux équipés d'un FAP.",
    brandId: brandLiquiMoly.id, categoryId: catACarburant.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1542362567-b07e54358753?w=800&q=80', altFr: 'Liqui Moly Diesel Additif' },
    ],
    variants: [
      { skuVariant: 'LM-DIESEL-500ML', volume: '500ml', price: 28.00, stock: 150 },
    ],
  })

  await mkProduct({
    sku: 'LM-MOS2-ADD', name: 'Liqui Moly MoS2 Anti-Friction 125ml', slug: 'liqui-moly-mos2-anti-friction',
    desc: "Additif anti-friction à base de bisulfure de molybdène (MoS2) qui se dépose en couche protectrice sur toutes les surfaces frottantes. Réduit l'usure au démarrage à froid de 30%, prolonge la vie du moteur et peut être utilisé dans toutes les huiles moteur. Un classique plébiscité par les mécaniciens tunisiens.",
    brandId: brandLiquiMoly.id, categoryId: catAMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1580983561371-7f4b242d8ec0?w=800&q=80', altFr: 'Liqui Moly MoS2 Anti-Friction' },
    ],
    variants: [
      { skuVariant: 'LM-MOS2-125ML', volume: '125ml', price: 22.00, stock: 200 },
    ],
  })

  await mkProduct({
    sku: 'TOT-ESSENCE-ADD', name: 'Total Injecto Cleaner Essence 250ml', slug: 'total-injecto-cleaner-essence',
    desc: "Nettoyant injecteurs pour moteurs essence. Dissout les dépôts de gomme et de vernis dans le système d'alimentation et sur les injecteurs. Améliore la pulvérisation du carburant et rétablit les performances d'origine. À utiliser à chaque vidange ou tous les 15 000 km.",
    brandId: brandTotal.id, categoryId: catACarburant.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1565008576549-57569a49371d?w=800&q=80', altFr: 'Total Injecto Cleaner' },
    ],
    variants: [
      { skuVariant: 'TOT-INJ-250ML', volume: '250ml', price: 16.00, stock: 180 },
    ],
  })

  // ── Filtres ───────────────────────────────────────────────────────
  await mkProduct({
    sku: 'PUR-FH-UNIV', name: 'Purflux Filtre à Huile LS895A', slug: 'purflux-filtre-huile-ls895a',
    desc: "Filtre à huile Purflux LS895A, compatible avec de nombreux modèles Renault, Dacia, Nissan, et Opel. Fabriqué selon les normes OEM d'origine. Papier filtrant haute efficacité (filtration jusqu'à 20 microns) avec clapet anti-retour intégré. Remplacement conseillé à chaque vidange.",
    brandId: brandYacco.id, categoryId: catFHuile.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&q=80', altFr: 'Purflux Filtre à Huile LS895A' },
    ],
    variants: [
      { skuVariant: 'PUR-FH-LS895A', volume: 'Unité', price: 12.00, stock: 250 },
    ],
    compatible: [
      { modelId: modelClio.id, engine: '1.5 dCi 75/90/110', yearFrom: 2012, yearTo: 2020 },
      { modelId: modelMegane.id, engine: '1.5 dCi 110/130', yearFrom: 2012, yearTo: 2019 },
      { modelId: modelLogan.id, engine: '1.5 dCi 75/90', yearFrom: 2012, yearTo: 2021 },
      { modelId: modelSandero.id, engine: '1.5 dCi 75/90', yearFrom: 2012, yearTo: 2021 },
    ],
  })

  await mkProduct({
    sku: 'MAN-FA-VW', name: 'Mann Filter Filtre à Air C 30 130/2', slug: 'mann-filter-air-c30130',
    desc: "Filtre à air Mann Filter C 30 130/2 pour moteurs Volkswagen Group (VAG). Élément filtrant en papier plissé haute densité, retenant 99,8% des particules. Garantit un air propre pour la combustion, réduit l'usure des cylindres et maintient les performances du moteur.",
    brandId: brandAreca.id, categoryId: catFAir.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80', altFr: 'Mann Filter Filtre à Air VW' },
    ],
    variants: [
      { skuVariant: 'MAN-FA-C30130', volume: 'Unité', price: 18.00, stock: 180 },
    ],
    compatible: [
      { modelId: modelGolf.id, engine: '1.6 TDI 105/110', yearFrom: 2008, yearTo: 2017 },
      { modelId: modelPolo.id, engine: '1.6 TDI 90/105', yearFrom: 2009, yearTo: 2017 },
      { modelId: modelA3.id, engine: '1.6 TDI 105', yearFrom: 2012, yearTo: 2018 },
    ],
  })

  await mkProduct({
    sku: 'MAN-FC-BMW', name: "Filtre d'Habitacle Carbon HEPA BMW", slug: 'filtre-habitacle-carbon-hepa-bmw',
    desc: "Filtre d'habitacle à charbon actif haute efficacité pour BMW Série 3 et Série 5. Retient 99,99% des particules fines PM2.5, pollens, bactéries et gaz. La couche de charbon actif élimine en outre les odeurs de carburant et d'ozone. Renouvellement conseillé tous les 15 000 km ou 1 an.",
    brandId: brandAreca.id, categoryId: catFHabitacle.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1614289371518-722f2615943d?w=800&q=80', altFr: "Filtre Habitacle Carbon BMW" },
    ],
    variants: [
      { skuVariant: 'MAN-FH-BMW-UNIT', volume: 'Unité', price: 24.00, stock: 100 },
    ],
    compatible: [
      { modelId: model3Series.id, engine: 'Tous moteurs F30', yearFrom: 2012, yearTo: 2019 },
      { modelId: model5Series.id, engine: 'Tous moteurs F10', yearFrom: 2010, yearTo: 2017 },
    ],
  })

  // ── Areca & Accor ─────────────────────────────────────────────────
  await mkProduct({
    sku: 'ARE-F600-5W30', name: 'Areca F600 5W-30 C3', slug: 'areca-f600-5w30-c3',
    desc: "Areca F600 5W-30 est une huile 100% synthétique de Classe C3, développée en France pour les moteurs essence et diesel modernes équipés de systèmes de dépollution (FAP/DPF). Faible teneur en cendres sulfatées (Low SAPS) pour préserver la durée de vie des filtres à particules.",
    brandId: brandAreca.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1621245131495-21d3f9479b15?w=800&q=80', altFr: 'Areca F600 5W-30' },
    ],
    variants: [
      { skuVariant: 'ARE-F600-1L', volume: '1L', price: 44.00, stock: 75 },
      { skuVariant: 'ARE-F600-5L', volume: '5L', price: 195.00, stock: 40 },
    ],
    specs: { viscosity: '5W-30', apiStandard: 'API SN', aeceaStandard: 'ACEA C3', isFullySynth: true },
  })

  await mkProduct({
    sku: 'ACC-HSY-10W40', name: 'Accor Husynn 10W-40', slug: 'accor-husynn-10w40',
    desc: "Accor Husynn 10W-40 est une huile tunisienne semi-synthétique spécialement formulée pour les conditions climatiques locales. Résistante aux fortes chaleurs estivales et aux températures hivernales fraîches du nord du pays. Très apprécié des mécaniciens tunisiens pour son excellent rapport qualité-prix.",
    brandId: brandAccor.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&q=80', altFr: 'Accor Husynn 10W-40' },
    ],
    variants: [
      { skuVariant: 'ACC-HSY-10W40-1L', volume: '1L', price: 22.00, stock: 220 },
      { skuVariant: 'ACC-HSY-10W40-5L', volume: '5L', price: 98.00, stock: 110 },
      { skuVariant: 'ACC-HSY-10W40-20L', volume: '20L', price: 355.00, stock: 25 },
    ],
    specs: { viscosity: '10W-40', apiStandard: 'API SL/CF', isSemiSynth: true },
    compatible: [
      { modelId: modelClio.id, engine: '1.2 16V 75', yearFrom: 2005, yearTo: 2019 },
      { modelId: modelPunto.id, engine: '1.2 69', yearFrom: 2006, yearTo: 2018 },
      { modelId: modelSwift.id, engine: '1.2 Dualjet 90', yearFrom: 2017, yearTo: 2023 },
    ],
  })

  await mkProduct({
    sku: 'VEE-DEX-5W30', name: 'Veedol Sigma X 5W-30 Long Life', slug: 'veedol-sigma-x-5w30',
    desc: "Veedol Sigma X 5W-30 est une huile synthétique longue durée conçue pour les moteurs modernes à économie de carburant. Réduction documentée de la consommation de carburant de 1.2% par rapport à une huile 10W-40. Excellente pour les SUV coréens et japonais circulant en Tunisie.",
    brandId: brandVeedol.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800&q=80', altFr: 'Veedol Sigma X 5W-30' },
    ],
    variants: [
      { skuVariant: 'VEE-SGM-5W30-1L', volume: '1L', price: 38.00, stock: 85 },
      { skuVariant: 'VEE-SGM-5W30-5L', volume: '5L', price: 172.00, stock: 45 },
    ],
    specs: { viscosity: '5W-30', apiStandard: 'API SN', aeceaStandard: 'ACEA A5/B5', isFullySynth: true },
    compatible: [
      { modelId: modelSportage.id, engine: '1.6 GDI 132', yearFrom: 2015, yearTo: 2022 },
      { modelId: modelTucson.id, engine: '1.6 CRDi 116', yearFrom: 2015, yearTo: 2021 },
      { modelId: modelCorolla.id, engine: '1.8 VVT-i 122', yearFrom: 2019, yearTo: 2023 },
    ],
  })

  await mkProduct({
    sku: 'GULF-ARROW-10W40', name: 'Gulf Arrow Ultra 10W-40', slug: 'gulf-arrow-ultra-10w40',
    desc: "Gulf Arrow Ultra 10W-40 est une huile semi-synthétique pour moteurs essence et diesel. Formule Gulf Super Synth qui offre une protection éprouvée dans des conditions difficiles. Très populaire dans les pays du Maghreb pour son excellent comportement aux hautes températures.",
    brandId: brandGulf.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=800&q=80', altFr: 'Gulf Arrow Ultra 10W-40' },
    ],
    variants: [
      { skuVariant: 'GULF-ARR-10W40-1L', volume: '1L', price: 25.00, stock: 160 },
      { skuVariant: 'GULF-ARR-10W40-4L', volume: '4L', price: 92.00, stock: 90 },
      { skuVariant: 'GULF-ARR-10W40-20L', volume: '20L', price: 415.00, stock: 20 },
    ],
    specs: { viscosity: '10W-40', apiStandard: 'API SL/CF', isSemiSynth: true },
    compatible: [
      { modelId: modelQashqai.id, engine: '1.5 dCi 115', yearFrom: 2014, yearTo: 2021 },
      { modelId: modelAstra.id, engine: '1.4 Turbo 140', yearFrom: 2015, yearTo: 2022 },
      { modelId: modelFocus.id, engine: '1.5 EcoBoost 150', yearFrom: 2014, yearTo: 2021 },
    ],
  })

  await mkProduct({
    sku: 'CAS-MAGNATEC-5W40', name: 'Castrol Magnatec 5W-40 C3', slug: 'castrol-magnatec-5w40-c3',
    desc: "Castrol Magnatec 5W-40 C3 contient des molécules intelligentes qui s'attachent à la surface des pièces du moteur dès l'instant où vous mettez le contact. Résultat : jusqu'à 75% d'usure en moins pendant le démarrage à froid — la phase la plus critique pour votre moteur.",
    brandId: brandCastrol.id, categoryId: catHMoteur.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1621245131495-21d3f9479b15?w=800&q=80', altFr: 'Castrol Magnatec 5W-40 C3' },
    ],
    variants: [
      { skuVariant: 'CAS-MAG-5W40-1L', volume: '1L', price: 42.00, stock: 95 },
      { skuVariant: 'CAS-MAG-5W40-4L', volume: '4L', price: 155.00, stock: 55 },
      { skuVariant: 'CAS-MAG-5W40-5L', volume: '5L', price: 188.00, stock: 45 },
    ],
    specs: { viscosity: '5W-40', apiStandard: 'API SN', aeceaStandard: 'ACEA C3', isSemiSynth: true },
    compatible: [
      { modelId: modelMegane.id, engine: '1.6 dCi 130', yearFrom: 2012, yearTo: 2019 },
      { modelId: modelC3.id, engine: '1.5 BlueHDi 100', yearFrom: 2016, yearTo: 2023 },
      { modelId: modelRio.id, engine: '1.4 CVVT 100', yearFrom: 2017, yearTo: 2023 },
    ],
  })

  // ── Industrielle ──────────────────────────────────────────────────
  await mkProduct({
    sku: 'MOB-DTE-46', name: 'Mobil DTE 25 Hydraulic Oil VG46', slug: 'mobil-dte-25-vg46',
    desc: "Huile hydraulique industrielle Mobil DTE 25, viscosité ISO VG 46. Recommandée pour les systèmes hydrauliques de machines-outils, presses, excavateurs et chariots élévateurs. Excellente stabilité d'oxydation, résistance à la mousse et protection anti-usure prolongeant la vie des pompes hydrauliques.",
    brandId: brandMobil.id, categoryId: catHIndustrielle.id, isFeatured: false,
    images: [
      { url: 'https://images.unsplash.com/photo-1565008576549-57569a49371d?w=800&q=80', altFr: 'Mobil DTE 25 Hydraulic Oil' },
    ],
    variants: [
      { skuVariant: 'MOB-DTE25-5L', volume: '5L', price: 68.00, stock: 50 },
      { skuVariant: 'MOB-DTE25-20L', volume: '20L', price: 240.00, stock: 20 },
      { skuVariant: 'MOB-DTE25-208L', volume: '208L', price: 2200.00, stock: 5 },
    ],
    specs: { apiStandard: 'ISO VG 46', aeceaStandard: 'DIN 51524' },
  })

  console.log('✅ KiosqueTN database seeded successfully!')
  console.log('')
  console.log('📊 Summary:')
  console.log('  - 1 Admin user (admin@kiosquetn.tn / admin123)')
  console.log('  - 12 Lubricant brands')
  console.log('  - 18 Vehicle makes + 33 vehicle models')
  console.log('  - 5 Parent categories + 14 sub-categories')
  console.log('  - 27 Products with full specs, images, variants & compatibility')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
