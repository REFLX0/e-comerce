import { Loader2 } from 'lucide-react'

export function LoadingSpinner({
  size = 24,
  className = '',
}: {
  size?: number
  className?: string
}) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <Loader2 size={size} className="text-brand-primary animate-spin" />
    </div>
  )
}
